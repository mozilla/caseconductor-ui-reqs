CHANGES
=======

0.1.3 (2011.07.06)
------------------

* Clicking ``label`` element within ``summary`` does not trigger expand/collapse.

0.1.2 (2011.07.06)
------------------

* Clicking ``input`` element within ``summary`` does not trigger expand/collapse.

0.1.1 (2011.06.25)
------------------

* Initial release.

