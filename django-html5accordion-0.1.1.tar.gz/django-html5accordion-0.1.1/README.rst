jQuery html5accordion plugin package for Django
===============================================
