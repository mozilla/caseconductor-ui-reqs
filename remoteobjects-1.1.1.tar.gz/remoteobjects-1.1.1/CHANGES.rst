remoteobjects Changelog
=======================

1.1.1 (2010-07-08)
------------------

* Applied a patch from Alex Gaynor to allow `None` for `Datetime` fields.


1.1 (2009-11-24)
----------------

* Added support for HEAD and OPTIONS request methods.
* Added some example client implementations (Netflix, Twitter, Giant Bomb, CouchDB)

1.0 (2009-09-30)
----------------

* Initial release.
