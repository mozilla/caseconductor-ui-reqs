Data Objects
============

.. automodule:: remoteobjects.dataobject

.. autoclass:: DataObject
   :members:

Helpers
-------

.. autofunction:: find_by_name
