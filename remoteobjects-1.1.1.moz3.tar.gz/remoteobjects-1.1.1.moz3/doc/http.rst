HTTP Objects
============

.. automodule:: remoteobjects.http
   :members:
